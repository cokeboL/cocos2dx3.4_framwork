local scene = cc.Scene:create()
local layer = cc.Layer:create()
scene:addChild(layer)

local text = ccui.Text:create()
text:setString("test update")
text:setPosition(cc.p(240, 160))
layer:addChild(text)

cc.Director:getInstance():replaceScene(scene)